/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package MyProject;

/**
 *
 * @author dol
 */
public class MyProject {

    public static void main(String[] args) {
        System.out.println("Hello World!");        
        System.out.println("Welcome to to club!!!");
    }
}

//Hey!!
